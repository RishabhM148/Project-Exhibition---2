package com.example.infinity_vault;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class SecondActivity extends AppCompatActivity {
    Button sendOtp;
    EditText mobileNumber;
    TextView wrongNo,textView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        textView = findViewById(R.id.otp_unlock_text);
        Intent intent = getIntent();
        String text = intent.getStringExtra("message_a");
        textView.setText("Unlocking " + text);
        if (text == null) {
            textView.setText("");
        }
        else
            textView.setText("Unlocking " + text);
        sendOtp = findViewById(R.id.sendotp);
        wrongNo = findViewById(R.id.wrong_number);
        mobileNumber = findViewById(R.id.mobile_number);
        sendOtp.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (mobileNumber.getText().length() == 10) {
                    Intent intent1 = new Intent(SecondActivity.this, OtpActivity.class);
                    intent1.putExtra("message_b",text);
                    startActivity(intent1);
                    Toast toast = Toast.makeText(getApplicationContext(), "Otp Sent Successful", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else{
                    wrongNo.setText("Please enter the valid mobile number");
                }
            }
        });
    }
}