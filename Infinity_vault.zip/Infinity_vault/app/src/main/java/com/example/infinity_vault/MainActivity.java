package com.example.infinity_vault;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button loginButton;
    EditText username, password;
    TextView wrongPass;
    TextView textView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.unlock_text);
        loginButton = findViewById(R.id.login_button);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        wrongPass = findViewById(R.id.wrong_pass);
        Intent intent = getIntent();
        String text = intent.getStringExtra("message");
        if (text == null) {
            textView.setText("");
        }
        else
            textView.setText("Unlocking " + text);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if (username.getText().length() != 0 && password.getText().length() != 0) {
                    if (username.getText().toString().equals("prakhar") && password.getText().toString().equals("gupta")) {

                        Intent intent1 = new Intent(MainActivity.this, SecondActivity.class);
                        intent1.putExtra("message_a",text);
                        startActivity(intent1);
                        Toast toast = Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT);
                        toast.show();
                    } else {
                        wrongPass.setText("You have entered wrong credentials");
                    }
                } else
                    wrongPass.setText("Please enter the username and password");
            }
        });
    }
}